/*#define a11 0.43945
#define a12 0.56128
#define a13 -2.6017e-005
#define a14 -4.7836e-005
#define a15 -1.1921e-007
#define a16 -336.0291
#define a21 0.53084
#define a22 -0.41773
#define a23 9.4511e-006
#define a24 1.7017e-005
#define a25 -1.9461e-005
#define a26 -147.5652*/

#define a11 0.68651
#define a12 0.080456
#define a13 -322.1862
#define a21 0.067412
#define a22 -0.69539
#define a23 373.1949

#define r1 78.3239
#define r2 66.44
#define r3 65.0264
#define r4 70.3613